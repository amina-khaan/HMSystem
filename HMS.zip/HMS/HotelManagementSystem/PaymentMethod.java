public class PaymentMethod implements PAyment {
    

    @Override
    public void CardPayment() {
        // TODO Auto-generated method stub
        //throw new UnsupportedOperationException("Unimplemented method 'CardPayment'");
    }

    @Override
    public void Cash() {
        // TODO Auto-generated method stub
        //throw new UnsupportedOperationException("Unimplemented method 'Cash'");
    }
    
}
