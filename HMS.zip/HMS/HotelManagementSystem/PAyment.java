public interface PAyment 
{
    void CardPayment();
    void Cash();   
}
