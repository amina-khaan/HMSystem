public class aaa{
    public static void main(String[] args)
    {
        String y = "3";
        int x = 3;
        System.out.println(x-y);
    }
}